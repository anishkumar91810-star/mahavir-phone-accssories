# Mahavir Phone Accessories — Connected Demo

1. Open `admin_panel.html` in a browser.
2. Open `customer_app.html` in the same browser/profile.
3. Admin में product price/stock बदलें; Customer App उसी browser storage से data पढ़ता है.
4. यह local connected demo है, production cloud backend नहीं. Real Android/iPhone sync के लिए Firebase/Supabase/API backend और real payment gateway जोड़ना होगा.
